# Appointments app initialization
