# Lawyers app initialization
