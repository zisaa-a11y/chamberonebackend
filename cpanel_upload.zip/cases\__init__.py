# Cases app initialization
