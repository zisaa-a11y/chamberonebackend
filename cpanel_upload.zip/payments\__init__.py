# Payments app initialization
