# Landing app initialization
