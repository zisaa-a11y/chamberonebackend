# Core Django Project Package
