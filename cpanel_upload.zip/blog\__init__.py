# Blog app initialization
